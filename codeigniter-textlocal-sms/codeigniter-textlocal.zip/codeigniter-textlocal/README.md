# codeigniter-textlocal-sms
Textlocal sms library integration for codeigniter. Send textlocal sms using codeigniter manipulated library.
